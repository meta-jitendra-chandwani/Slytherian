export class timelines {
    id: number;
    timelinePeriod: string;
}